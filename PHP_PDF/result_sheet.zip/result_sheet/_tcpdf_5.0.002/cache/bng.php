﻿
<style type="text/css">
 #slip_table table tr td{
    border:1px solid #1d1d1d;
 }
</style>

<p> echo 'test';নাম    আইডি
</p>
আইডি
<?
echo 'test';
?>

<table align="center">
	<tr>
		<th style="text-align:center;font-size:17px;font-family:Arial;">
			Abc Company</th>
	</tr>
	<tr>
		<td style="text-align:center;font-family:Arial;">R#15,H#255,block-a,mohakhali,DOHS</td>
	</tr>
</table>
<br/>

<table align="center" style="font-family:Arial;">
	<tr><td>Date from: 20/12/2012</td>
	<td>&nbsp;&nbsp;</td><td>&nbsp;&nbsp;</td>
	<td>&nbsp;&nbsp;</td><td>&nbsp;&nbsp;</td>
	<td>&nbsp;&nbsp;</td><td>&nbsp;&nbsp;</td>
	<td>Date to: 28/12/2012</td>	
	</tr>
	<tr><td>Dept: Kniting</td>
	<td>&nbsp;&nbsp;</td><td>&nbsp;&nbsp;</td>
	<td>&nbsp;&nbsp;</td><td>&nbsp;&nbsp;</td>
	<td>&nbsp;&nbsp;</td><td>&nbsp;&nbsp;</td>
	<td>Sub Dept: Nai</td>	
	</tr>
</table>

<hr/>

<table  align="center" style="font-family:Arial;">
  <tr>
    <th>ID:</th>
	<td> G5200R</td>
	<th>Name:</th>
	<td> Mr. Abul Mal Abdul Muhid &nbsp;</td>
	<th>Grade:</th>
	<td> A</td>
	<th> Designation:</th>
	<td> Jr. Operator&nbsp;</td>	
  </tr>
</table>
<hr/>
<table  id="slip_table" align="center">  
  <tr  style="border:1px thin #1d1d1d;font-family:Arial;">
    <th>Basic</th>
	<th>House</th>
	<th>Medical</th>
	<th>Attendance</th>
	<th>PC Rate Pay</th>
	<th>Holyday</th>
	<th>Revenue Stamp</th>
	<th>No Job</th>	
	<th>Gross</th>	
	<th>Net Total</th>
  </tr>    
  <tr  style="border:1px thin #1d1d1d;font-family:Arial;">
    <td>6500&nbsp;</td>
	<td>1200&nbsp; </td>
	<td>1100&nbsp; </td>
	<td>1000&nbsp;</td>
	<td>200&nbsp;</td>
	<td>4&nbsp;</td>
	<td>23&nbsp;</td>	
	<td>10&nbsp;</td>
	<td>20&nbsp;</td>
	<td>10057&nbsp;</td>
  </tr>  
</table>
<br/>
<hr/>
<table  align="center" style="text-align:center;font-family:Arial;">  
  <tr>
    <td>Eight thousand five hundred taka only</td>
	<td>&nbsp;&nbsp;&nbsp;</td>
	<td>&nbsp;&nbsp;&nbsp;</td>
	<td>&nbsp;&nbsp;&nbsp;</td>
	<td>&nbsp;&nbsp;&nbsp;</td>
	<td>&nbsp;&nbsp;&nbsp;</td>
	<td>&nbsp;&nbsp;&nbsp;</td>
	<td>Signature</td>
  </tr>    
</table>