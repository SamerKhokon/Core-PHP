<?php   ob_start(); ?>


    <p><span style="font-weight:bold;font-size:14px;color:#0000aa;font-family:Arial;">1. Applicant Details</span><br/>
	<span style="font-size:16px;color:#000;font-family:Arial;">
	Please detail your family name and fullname as it 	appears in your SSC/O Level/National ID Card/Passport.
	</span>
	</p>

	<table align="center" cellpadding="0" cellspacing="0" border="0" width="100%" style="border:1px solid #000;">
		<tr>
			<th style="text-align:center;width:420px;height:30px;background-color:#a9a9a9;color:#fff;border-left:1px solid #000;border-top:1px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:0px solid #000;">Title:Mr/Mrs/Miss/Ms(put tick mark as applicable)</th>
			<th style="text-align:center;width:320px;height:30px;background-color:#a9a9a9;color:#fff;border-left:1px solid #000;border-top:1px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:1px solid #000;" >Date of Birth(dd/mm/yy)</th>			
		</tr>
		<tr>
			<td style="height:30px;background-color:#fff;color:#000;border-left:1px solid #000;border-top:0px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:0px solid #000;">&nbsp;Name(block capital):</td>
			<td style="height:30px;background-color:#fff;color:#000;border-left:1px solid #000;border-top:0px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:1px solid #000;" >Male/Female&nbsp;&nbsp;&nbsp;&nbsp;  Blood Group:</td>			
		</tr>
		<tr>
			<td style="height:30px;background-color:#fff;color:#000;border-left:1px solid #000;border-top:0px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:0px solid #000;">&nbsp;Present Add:</td>
			<td style="height:30px;background-color:#fff;color:#000;border-left:1px solid #000;border-top:0px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:1px solid #000;" >&nbsp;Religion:&nbsp;&nbsp;&nbsp;&nbsp;  </td>			
		</tr>
		<tr>
			<td style="height:30px;background-color:#fff;color:#000;border-left:1px solid #000;border-top:0px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:0px solid #000;"></td>
			<td style="height:30px;background-color:#fff;color:#000;border-left:1px solid #000;border-top:0px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:1px solid #000;" >&nbsp;Nationality:&nbsp;&nbsp;&nbsp;&nbsp;  </td>			
		</tr>
		<tr>
			<td style="height:30px;background-color:#fff;color:#000;border-left:1px solid #000;border-top:0px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:0px solid #000;">&nbsp;Parmanent Add:</td>
			<td style="height:30px;background-color:#fff;color:#000;border-left:1px solid #000;border-top:0px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:1px solid #000;" >&nbsp;National ID card no:(attatch a copy)&nbsp;&nbsp;&nbsp;&nbsp;  </td>			
		</tr>
		<tr>
			<td style="height:30px;background-color:#fff;color:#000;border-left:1px solid #000;border-top:0px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:0px solid #000;"></td>
			<td style="height:30px;background-color:#fff;color:#000;border-left:1px solid #000;border-top:0px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:1px solid #000;" >&nbsp;Passport No:&nbsp;&nbsp;&nbsp;&nbsp;  </td>			
		</tr>
		<tr>
			<td style="height:30px;background-color:#fff;color:#000;border-left:1px solid #000;border-top:0px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:0px solid #000;">&nbsp;Country: Post Code:</td>
			<td style="height:30px;background-color:#fff;color:#000;border-left:1px solid #000;border-top:0px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:1px solid #000;" >&nbsp;Mobile No<span style="font-size:9px;font-weight:italic;">(incl Intl Code)</span>:&nbsp;&nbsp;&nbsp;&nbsp;  </td>			
		</tr>
		<tr>
			<td style="height:30px;background-color:#fff;color:#000;border-left:1px solid #000;border-top:0px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:0px solid #000;">&nbsp;Tel No<span style="font-size:9px;font-weight:italic;">(incl Intl Code)</span>: </td>
			<td style="height:30px;background-color:#fff;color:#000;border-left:1px solid #000;border-top:0px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:1px solid #000;" >&nbsp;Email:&nbsp;&nbsp;&nbsp;&nbsp;  </td>			
		</tr>		
	</table>
	
	<br/><br/>
	<table align="center" cellpadding="0" cellspacing="0" border="0" width="100%" style="border:1px solid #000;">
		<tr>
			<td style="height:30px;text-align:center;width:200px;background-color:#a9a9a9;color:#fff;border-left:1px solid #000;border-top:1px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:0px solid #000;">Mother`s Name</td>
			<td style="height:30px;text-align:center;width:100px;background-color:#a9a9a9;color:#fff;border-left:1px solid #000;border-top:1px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:0px solid #000;" >Occupation</td>
			<td style="height:30px;text-align:center;width:100px;background-color:#a9a9a9;color:#fff;border-left:1px solid #000;border-top:1px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:0px solid #000;">Yearly<br/> Income</td>
			<td style="height:30px;text-align:center;width:100px;background-color:#a9a9a9;color:#fff;border-left:1px solid #000;border-top:1px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:0px solid #000;" >National Id<br/>Card No</td>						
			<td style="height:30px;text-align:center;width:100px;background-color:#a9a9a9;color:#fff;border-left:1px solid #000;border-top:1px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:0px solid #000;">Cont No</td>
			<td style="height:30px;text-align:center;width:100px;background-color:#a9a9a9;color:#fff;border-left:1px solid #000;border-top:1px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:1px solid #000;" >Email</td>									
		</tr>
		<tr>
			<td style="height:30px;background-color:#fff;color:#000;border-left:1px solid #000;border-top:0px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:0px solid #000;">&nbsp;&nbsp;&nbsp;&nbsp;</td>
			<td style="height:30px;background-color:#fff;color:#000;border-left:1px solid #000;border-top:0px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:0px solid #000;" >&nbsp;&nbsp;&nbsp;&nbsp;  </td>	
			<td style="height:30px;background-color:#fff;color:#000;border-left:1px solid #000;border-top:0px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:0px solid #000;" >&nbsp;&nbsp;&nbsp;&nbsp;  </td>			
			<td style="height:30px;background-color:#fff;color:#000;border-left:1px solid #000;border-top:0px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:0px solid #000;" >&nbsp;&nbsp;&nbsp;&nbsp;  </td>			
			<td style="height:30px;background-color:#fff;color:#000;border-left:1px solid #000;border-top:0px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:0px solid #000;" >&nbsp;&nbsp;&nbsp;&nbsp;  </td>			
			<td style="height:30px;background-color:#fff;color:#000;border-left:1px solid #000;border-top:0px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:1px solid #000;" >&nbsp;&nbsp;&nbsp;&nbsp;  </td>						
		</tr>
	</table>	
	
	
	<br/><br/>
	<table align="center" cellpadding="0" cellspacing="0" border="0" width="100%" style="border:1px solid #000;">
		<tr>
			<td style="height:30px;text-align:center;width:200px;background-color:#a9a9a9;color:#fff;border-left:1px solid #000;border-top:1px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:0px solid #000;">Father`s Name</td>
			<td style="height:30px;text-align:center;width:100px;background-color:#a9a9a9;color:#fff;border-left:1px solid #000;border-top:1px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:0px solid #000;" >Occupation</td>
			<td style="height:30px;text-align:center;width:100px;background-color:#a9a9a9;color:#fff;border-left:1px solid #000;border-top:1px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:0px solid #000;">Yearly<br/> Income</td>
			<td style="height:30px;text-align:center;width:100px;background-color:#a9a9a9;color:#fff;border-left:1px solid #000;border-top:1px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:0px solid #000;" >National Id<br/>Card No</td>						
			<td style="height:30px;text-align:center;width:100px;background-color:#a9a9a9;color:#fff;border-left:1px solid #000;border-top:1px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:0px solid #000;">Cont No</td>
			<td style="height:30px;text-align:center;width:100px;background-color:#a9a9a9;color:#fff;border-left:1px solid #000;border-top:1px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:1px solid #000;" >Email</td>									
		</tr>
		<tr>
			<td style="height:30px;background-color:#fff;color:#000;border-left:1px solid #000;border-top:0px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:0px solid #000;">&nbsp;&nbsp;&nbsp;&nbsp;</td>
			<td style="height:30px;background-color:#fff;color:#000;border-left:1px solid #000;border-top:0px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:0px solid #000;" >&nbsp;&nbsp;&nbsp;&nbsp;  </td>	
			<td style="height:30px;background-color:#fff;color:#000;border-left:1px solid #000;border-top:0px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:0px solid #000;" >&nbsp;&nbsp;&nbsp;&nbsp;  </td>			
			<td style="height:30px;background-color:#fff;color:#000;border-left:1px solid #000;border-top:0px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:0px solid #000;" >&nbsp;&nbsp;&nbsp;&nbsp;  </td>			
			<td style="height:30px;background-color:#fff;color:#000;border-left:1px solid #000;border-top:0px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:0px solid #000;" >&nbsp;&nbsp;&nbsp;&nbsp;  </td>			
			<td style="height:30px;background-color:#fff;color:#000;border-left:1px solid #000;border-top:0px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:1px solid #000;" >&nbsp;&nbsp;&nbsp;&nbsp;  </td>						
		</tr>
	</table>
	
	
	
	<br/><br/>
	<table align="center" cellpadding="0" cellspacing="0" border="0" width="100%" style="border:1px solid #000;">
		<tr>
			<td style="height:30px;text-align:center;width:200px;background-color:#a9a9a9;color:#fff;border-left:1px solid #000;border-top:1px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:0px solid #000;">Name of Local Guardian</td>
			<td style="height:30px;text-align:center;width:100px;background-color:#a9a9a9;color:#fff;border-left:1px solid #000;border-top:1px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:0px solid #000;" >Occupation</td>
			<td style="height:30px;text-align:center;width:100px;background-color:#a9a9a9;color:#fff;border-left:1px solid #000;border-top:1px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:0px solid #000;">Yearly<br/> Income</td>
			<td style="height:30px;text-align:center;width:100px;background-color:#a9a9a9;color:#fff;border-left:1px solid #000;border-top:1px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:0px solid #000;" >National Id<br/>Card No</td>						
			<td style="height:30px;text-align:center;width:100px;background-color:#a9a9a9;color:#fff;border-left:1px solid #000;border-top:1px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:0px solid #000;">Cont No</td>
			<td style="height:30px;text-align:center;width:100px;background-color:#a9a9a9;color:#fff;border-left:1px solid #000;border-top:1px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:1px solid #000;" >Email</td>									
		</tr>
		<tr>
			<td style="height:30px;background-color:#fff;color:#000;border-left:1px solid #000;border-top:0px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:0px solid #000;">&nbsp;&nbsp;&nbsp;&nbsp;</td>
			<td style="height:30px;background-color:#fff;color:#000;border-left:1px solid #000;border-top:0px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:0px solid #000;" >&nbsp;&nbsp;&nbsp;&nbsp;  </td>	
			<td style="height:30px;background-color:#fff;color:#000;border-left:1px solid #000;border-top:0px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:0px solid #000;" >&nbsp;&nbsp;&nbsp;&nbsp;  </td>			
			<td style="height:30px;background-color:#fff;color:#000;border-left:1px solid #000;border-top:0px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:0px solid #000;" >&nbsp;&nbsp;&nbsp;&nbsp;  </td>			
			<td style="height:30px;background-color:#fff;color:#000;border-left:1px solid #000;border-top:0px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:0px solid #000;" >&nbsp;&nbsp;&nbsp;&nbsp;  </td>			
			<td style="height:30px;background-color:#fff;color:#000;border-left:1px solid #000;border-top:0px solid #000;border-bottom:1px solid #000;font-size:14px;border-right:1px solid #000;" >&nbsp;&nbsp;&nbsp;&nbsp;  </td>						
		</tr>
	</table>
	
<?php 
$content = ob_get_clean();
		// convert to PDF

		include('html2pdf.class.php');				
		try
		{
			$html2pdf = new HTML2PDF('P', 'A4', 'fr');
			$html2pdf->pdf->SetDisplayMode('fullpage');
			$html2pdf->writeHTML($content, isset($_GET['vuehtml']));
			$html2pdf->Output('_term_result_sheet.pdf');
		}
		catch(HTML2PDF_exception $e)
		{
			echo $e;
			exit;
		}
?>