<?php
    include('numword.php');
	
	$word = new ext_functions();
    echo $amount->word(550);
?>