<script type="text/javascript">
/*
window.showModalDialog("search_result.php?date="+date_picker 
				     , "mywindow" 
					 , "dialogWidth:980px;dialogHeight:840px;");				
			}
*/
  function w(){
	window.showModalDialog("result_sheet.php" , "mywindow" , "dialogWidth:1000px;dialogHeight:800px;");				
	
  }
</script>
<a href="javascript:void(0);" onclick="w();">
<input type="button" value="save"/>
</a>