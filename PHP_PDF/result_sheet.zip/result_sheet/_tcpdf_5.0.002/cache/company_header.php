<table align="center">
	<tr>
		<th style="text-align:center;font-size:17px;font-family:Arial;">
			Abc Company</th>
	</tr>
	<tr>
		<td style="text-align:center;font-family:Arial;">R#15,H#255,block-a,mohakhali,DOHS</td>
	</tr>
</table>